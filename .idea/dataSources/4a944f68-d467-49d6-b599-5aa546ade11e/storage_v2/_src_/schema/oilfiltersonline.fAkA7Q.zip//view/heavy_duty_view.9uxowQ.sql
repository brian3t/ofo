CREATE VIEW heavy_duty_view AS
  SELECT
    `parts`.`part`              AS `part`,
    `parts`.`year`              AS `year`,
    `parts`.`make`              AS `make`,
    `parts`.`model`             AS `model`,
    `parts`.`engine`            AS `engine`,
    `parts`.`type`              AS `type`,
    `parts`.`manufacturer`      AS `manufacturer`,
    `store`.`is_showing`        AS `Active`,
    `store`.`sales_price`       AS `price`,
    `parts`.`description`       AS `description`,
    `desc`.`content`            AS `content`,
    `store`.`tiny_image`        AS `thumbnail`,
    `store`.`big_image`         AS `bigimage`,
    `store`.`item_name`         AS `store_name`,
    `store`.`price`             AS `retail_price`,
    `store`.`use_stock_level`   AS `use_stock_level`,
    `store`.`stock_level`       AS `stock_level`,
    `store`.`shipping_in_stock` AS `shipping_in_stock`,
    `store`.`friendly_url`      AS `friendly_url`
  FROM ((`oilfiltersonline`.`heavy_duty` `parts` LEFT JOIN `oilfiltersonline`.`aaia_descriptions` `desc`
      ON ((`parts`.`description` = `desc`.`description`))) LEFT JOIN `oilfiltersonline_test_store`.`va_items` `store`
      ON ((`parts`.`part` = `store`.`item_code`)));

