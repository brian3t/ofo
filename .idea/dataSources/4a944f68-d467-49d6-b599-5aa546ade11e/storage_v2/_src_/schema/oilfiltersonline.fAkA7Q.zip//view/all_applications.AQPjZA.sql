CREATE VIEW all_applications AS
  (SELECT
     `oilfiltersonline`.`automotive_parts`.`year`   AS `year`,
     `oilfiltersonline`.`automotive_parts`.`make`   AS `make`,
     `oilfiltersonline`.`automotive_parts`.`model`  AS `model`,
     `oilfiltersonline`.`automotive_parts`.`engine` AS `engine`,
     `oilfiltersonline`.`automotive_parts`.`part`   AS `part`
   FROM `oilfiltersonline`.`automotive_parts`)
  UNION ALL (SELECT
               `oilfiltersonline`.`heavy_duty_parts`.`year`   AS `year`,
               `oilfiltersonline`.`heavy_duty_parts`.`make`   AS `make`,
               `oilfiltersonline`.`heavy_duty_parts`.`model`  AS `model`,
               `oilfiltersonline`.`heavy_duty_parts`.`engine` AS `engine`,
               `oilfiltersonline`.`heavy_duty_parts`.`part`   AS `part`
             FROM `oilfiltersonline`.`heavy_duty_parts`)
  UNION ALL (SELECT
               `oilfiltersonline`.`motorcycle_parts`.`year`   AS `year`,
               `oilfiltersonline`.`motorcycle_parts`.`make`   AS `make`,
               `oilfiltersonline`.`motorcycle_parts`.`model`  AS `model`,
               `oilfiltersonline`.`motorcycle_parts`.`engine` AS `engine`,
               `oilfiltersonline`.`motorcycle_parts`.`part`   AS `part`
             FROM `oilfiltersonline`.`motorcycle_parts`);

