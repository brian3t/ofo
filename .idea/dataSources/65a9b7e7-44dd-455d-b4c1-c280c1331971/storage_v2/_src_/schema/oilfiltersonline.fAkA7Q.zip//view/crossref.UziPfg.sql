CREATE VIEW crossref AS
  SELECT
    `parts`.`Part`        AS `Part`,
    `parts`.`C_Part`      AS `C_Part`,
    `parts`.`Competitor`  AS `Competitor`,
    `store`.`sales_price` AS `price`
  FROM (`oilfiltersonline`.`comp_cross_ref` `parts` LEFT JOIN `oilfiltersonline_test_store`.`va_items` `store` ON ((`parts`.`Part` = `store`.`item_code`)));

