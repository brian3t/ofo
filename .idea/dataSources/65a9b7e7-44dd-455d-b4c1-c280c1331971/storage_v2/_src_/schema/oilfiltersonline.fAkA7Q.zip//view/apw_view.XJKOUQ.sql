CREATE VIEW apw_view AS
  SELECT
    `store`.`item_code`               AS `item`,
    `store`.`use_stock_level`         AS `use_stock_level`,
    `store`.`stock_level`             AS `stock_level`,
    `store`.`shipping_in_stock`       AS `shipping_in_stock`,
    `store`.`shipping_out_stock`      AS `shipping_out_stock`,
    `parts`.`Stock`                   AS `apwstock`,
    `parts`.`vendor_cost`             AS `cost`,
    `manufacturers`.`manufacturer_id` AS `manufacturer_id`
  FROM
    ((`oilfiltersonline`.`apw` `parts` LEFT JOIN `oilfiltersonline_test_store`.`va_items` `store` ON ((`store`.`item_code` = `parts`.`vendor_sku`))) LEFT JOIN
      `oilfiltersonline_test_store`.`va_manufacturers` `manufacturers` ON ((`parts`.`vendor_brand` = `manufacturers`.`manufacturer_name`)))
  WHERE (`store`.`item_code` IS NOT NULL);

