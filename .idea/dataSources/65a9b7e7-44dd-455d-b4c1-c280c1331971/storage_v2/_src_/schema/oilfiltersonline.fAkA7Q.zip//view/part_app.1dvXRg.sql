CREATE VIEW part_app AS
  (SELECT
     `parts`.`part`                            AS `part`,
     `oilfiltersonline`.`aaia`.`year`          AS `year`,
     `oilfiltersonline`.`aaia`.`make`          AS `make`,
     `oilfiltersonline`.`aaia`.`model`         AS `model`,
     `oilfiltersonline`.`aaia`.`cylinders`     AS `cylinders`,
     `oilfiltersonline`.`aaia`.`liters`        AS `liters`,
     `oilfiltersonline`.`aaia`.`fuelType`      AS `fuelType`,
     `oilfiltersonline`.`aaia`.`injectionType` AS `injectionType`
   FROM ((SELECT DISTINCT
            `oilfiltersonline`.`aaia_parts`.`part` AS `part`,
            `oilfiltersonline`.`aaia_parts`.`aaia` AS `aaia`
          FROM `oilfiltersonline`.`aaia_parts`) `parts`
     JOIN `oilfiltersonline`.`aaia` ON ((`parts`.`aaia` = `oilfiltersonline`.`aaia`.`id`))));

