CREATE VIEW motorcycle_parts_view AS
  SELECT
    `parts`.`year`         AS `year`,
    `parts`.`make`         AS `make`,
    `parts`.`model`        AS `model`,
    `parts`.`engine`       AS `engine`,
    `parts`.`part`         AS `part`,
    `parts`.`type`         AS `type`,
    `parts`.`manufacturer` AS `manufacturer`,
    `store`.`is_showing`   AS `Active`,
    `store`.`sales_price`  AS `price`,
    `cat`.`sort_order`     AS `sort_order`,
    `cat`.`bgcolor`        AS `bgcolor`,
    `cat`.`category`       AS `category`,
    `cat`.`description`    AS `description`,
    `cat`.`part_group`     AS `part_group`
  FROM ((`oilfiltersonline`.`motorcycle_parts` `parts` LEFT JOIN `oilfiltersonline`.`part_categories` `cat` ON ((`parts`.`type` = `cat`.`type`))) LEFT JOIN
    `oilfiltersonline_test_store`.`va_items` `store` ON ((`parts`.`part` = `store`.`item_code`)));

