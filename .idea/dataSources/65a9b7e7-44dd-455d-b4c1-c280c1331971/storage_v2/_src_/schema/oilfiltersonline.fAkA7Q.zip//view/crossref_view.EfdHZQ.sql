CREATE VIEW crossref_view AS
  SELECT
    `parts`.`Part`         AS `Part`,
    `parts`.`C_Part`       AS `C_Part`,
    `parts`.`Competitor`   AS `Competitor`,
    `store`.`tiny_image`   AS `thumbnail`,
    `store`.`big_image`    AS `bigimage`,
    `store`.`sales_price`  AS `price`,
    `store`.`friendly_url` AS `friendly_url`
  FROM (`oilfiltersonline`.`comp_cross_ref` `parts` LEFT JOIN `oilfiltersonline_test_store`.`va_items` `store` ON ((`parts`.`Part` = `store`.`item_code`)));

